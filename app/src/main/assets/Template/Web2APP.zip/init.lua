appname=$appname$
appver="0.1"
appcode="1"
path_pattern=""
appsdk="21"
packagename=$packagename$
theme="Theme_Black_NoTitleBar_Fullscreen"
app_key=""
appSdk_target="23"
app_channel=""
developer=""
description=""
BuildScript=""
debugmode=true
isRemoveInitLua=true
NotAddFile={}
NotLuaCompile={}
NoAddDir={}
MergeDex={}
OpenTeal=false
AddJar={}

user_permission={
  "INTERNET"
}

Teal={
  

}

CustomizeApkPath={
  

}
