require "import"
import "android.text.Spannable"
import "android.view.Gravity"
import "android.widget.ImageView"
import "android.webkit.WebViewClient"
import "android.view.WindowManager"
import "android.view.inputmethod.InputMethodManager"
import "android.text.SpannableString"
import "android.widget.FrameLayout"
import "android.graphics.drawable.ColorDrawable"
import "android.os.Build"
import "android.webkit.WebView"
import "android.text.style.ForegroundColorSpan"
import "android.widget.CardView"
import "android.content.Context"
import "android.webkit.CookieSyncManager"
import "android.webkit.CookieManager"
import "android.widget.LinearLayout"
import "android.view.View"
import "Tools"
activity.setContentView("layout")
Url="https://www.baidu.com"
--请在此字符串内处填上要让app访问的网页

webSettings = myWebView.getSettings();
--支持JS(建议无论如何加上)
webSettings.setJavaScriptEnabled(true);
--无广告百度UA字符串
APP_NAME_UA="Mozilla/5.0 (Linux; Android 7.0; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/48.0.2564.116 Mobile Safari/537.36 T7/10.3 SearchCraft/2.6.2 (Baidu; P1 7.0)"
--自定义UA
webSettings.setUserAgentString(webSettings.getUserAgentString()..APP_NAME_UA);

--WebView设置字体大小:100表示正常,120表示文字放大1.2倍
webSettings.setTextZoom(100)
SearchViewLayout.setVisibility(View.INVISIBLE)
myWebView.loadUrl(Url)
myWebView.setWebViewClient( WebViewClient())
imm = activity.getSystemService(Context.INPUT_METHOD_SERVICE)
imm.toggleSoftInput(0,InputMethodManager.HIDE_NOT_ALWAYS)
myWebView.setWebViewClient{
  shouldOverrideUrlLoading=function(view,url)
    --Url即将跳转
  end,
  onPageStarted=function(view,url,favicon)
    --网页加载
  end,
  onPageFinished=function(view,url)
    --网页加载完成
  end}

myWebView.setWebChromeClient(LuaWebView.LuaWebChromeClient({
  onShowFileChooser=function(webView,filePathCallback,fileChooserParams)
    mUploadMessageAboveArray = filePathCallback
    intent = Intent(Intent.ACTION_GET_CONTENT)
    intent.setType("*/*");
    intent.addCategory(Intent.CATEGORY_OPENABLE)
    activity.startActivityForResult(intent,1);
    return true
  end,
  openFileChooser=function(uploadMsg)
    mUploadMessageAbove=uploadMsg
  end
}))


function onActivityResult(requestCode,resultCode,data)
  if resultCode == Activity.RESULT_OK then
    local str = data.getData().toString()
    local ret=Uri[1]
    ret[0]=Uri.parse(str)
    if mUploadMessageAboveArray
      mUploadMessageAboveArray.onReceiveValue(ret)
     else
      mUploadMessageAbove.onReceiveValue(ret[0])
    end
  end
end